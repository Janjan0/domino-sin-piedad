using SinPiedad.Game.Table;

namespace SinPiedad.Game.Domino {
    public static class DominoValidation {
        public static bool CanPlay(DominoTileData tile, int endpointValue) => tile.Matches(endpointValue);
        public static bool CanPlayEither(DominoTileData tile, int left, int right) => tile.Matches(left)||tile.Matches(right);
    }
}
