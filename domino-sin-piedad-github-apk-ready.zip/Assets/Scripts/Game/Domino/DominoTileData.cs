using System;
using UnityEngine;

namespace SinPiedad.Game.Domino {
    [Serializable]
    public readonly struct DominoTileData : IEquatable<DominoTileData> {
        public readonly int A;
        public readonly int B;
        public DominoTileData(int a, int b) { A = a; B = b; }
        public bool IsDouble => A == B;
        public int Sum => A + B;
        public bool Matches(int value) => A == value || B == value;
        public int Other(int value) => A == value ? B : (B == value ? A : -1);
        public bool Equals(DominoTileData o) => A == o.A && B == o.B;
        public override bool Equals(object o) => o is DominoTileData d && Equals(d);
        public override int GetHashCode() => HashCode.Combine(A, B);
        public override string ToString() => $"{A}|{B}";
    }
}
