using System.Collections.Generic;
using UnityEngine;

namespace SinPiedad.Game.Domino {
    public sealed class DominoDeck {
        public IReadOnlyList<DominoTileData> Tiles => _tiles;
        readonly List<DominoTileData> _tiles = new();
        public DominoDeck(int maxValue = 6) {
            for (int a = 0; a <= maxValue; a++) for (int b = a; b <= maxValue; b++) _tiles.Add(new DominoTileData(a,b));
        }
        public void Shuffle(System.Random rng) {
            for (int i=_tiles.Count-1;i>0;i--) { int j=rng.Next(i+1); (_tiles[i],_tiles[j])=(_tiles[j],_tiles[i]); }
        }
    }
}
