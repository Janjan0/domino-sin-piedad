using UnityEngine;
using SinPiedad.Game.Domino;

namespace SinPiedad.Game.Table {
    public sealed class PlacementManager : MonoBehaviour {
        public BoardGeometry Geometry { get; private set; } = new BoardGeometry();
        public bool TryPlay(DominoTileData tile, bool rightEnd, Vector2 dropPosition, out PlacedDomino placed) => Geometry.TryPlace(tile,rightEnd,dropPosition,out placed);
        public Vector2 LeftEndpoint => Geometry.GetEndpoint(false);
        public Vector2 RightEndpoint => Geometry.GetEndpoint(true);
        public void ResetBoard()=>Geometry.Clear();
    }
}
