using System.Collections.Generic;
using UnityEngine;
using SinPiedad.Game.Domino;

namespace SinPiedad.Game.Table {
    public enum DominoDirection { Right, Down, Left, Up }
    public readonly struct PlacedDomino {
        public readonly DominoTileData Tile; public readonly Vector2 Center; public readonly DominoDirection Direction;
        public PlacedDomino(DominoTileData tile, Vector2 center, DominoDirection direction){Tile=tile;Center=center;Direction=direction;}
    }

    // Real chain geometry: endpoints are derived from rectangle geometry, not a grid/list.
    public sealed class BoardGeometry {
        public float Length = 1.60f, Width = 0.72f, Padding = 0.05f;
        readonly List<PlacedDomino> _placed = new();
        public IReadOnlyList<PlacedDomino> Placed => _placed;
        public Vector2 Start = Vector2.zero;

        public bool TryPlace(DominoTileData tile, bool rightEnd, Vector2 desired, out PlacedDomino result) {
            result = default;
            if (_placed.Count == 0) { result = new PlacedDomino(tile, Start, DominoDirection.Right); _placed.Add(result); return true; }
            Vector2 endpoint = GetEndpoint(rightEnd);
            DominoDirection baseDir = GetEndpointDirection(rightEnd);
            var candidates = BuildCandidates(endpoint, baseDir, desired);
            foreach (var c in candidates) {
                var p = new PlacedDomino(tile, c.center, c.dir);
                if (!Overlaps(p) && Inside(p)) { _placed.Add(p); result=p; return true; }
            }
            return false;
        }
        public Vector2 GetEndpoint(bool rightEnd) {
            var p=_placed[rightEnd?_placed.Count-1:0]; var axis=Axis(p.Direction);
            return p.Center + axis * (rightEnd ? Length/2f : -Length/2f);
        }
        public DominoDirection GetEndpointDirection(bool rightEnd) => _placed[rightEnd?_placed.Count-1:0].Direction;
        static Vector2 Axis(DominoDirection d)=>d switch {DominoDirection.Right=>Vector2.right,DominoDirection.Left=>Vector2.left,DominoDirection.Down=>Vector2.down,_=>Vector2.up};
        IEnumerable<(Vector2 center,DominoDirection dir)> BuildCandidates(Vector2 e, DominoDirection dir, Vector2 desired) {
            var same=dir; var perp1=(DominoDirection)(((int)dir+1)%4); var perp2=(DominoDirection)(((int)dir+3)%4);
            Vector2 a=Axis(same), b=Axis(perp1), c=Axis(perp2);
            yield return (e+a*Length/2f,same); yield return (e-a*Length/2f,same);
            yield return (e+b*Length/2f,perp1); yield return (e-b*Length/2f,perp1);
            yield return (e+c*Length/2f,perp2); yield return (e-c*Length/2f,perp2);
        }
        Rect RectOf(PlacedDomino p){bool horiz=p.Direction==DominoDirection.Right||p.Direction==DominoDirection.Left; float x=horiz?Length:Width,y=horiz?Width:Length; return new Rect(p.Center-new Vector2(x,y)/2f,new Vector2(x,y));}
        bool Overlaps(PlacedDomino p){var r=RectOf(p); r.xMin-=Padding;r.xMax+=Padding;r.yMin-=Padding;r.yMax+=Padding; foreach(var q in _placed) if(r.Overlaps(RectOf(q))) return true; return false;}
        bool Inside(PlacedDomino p){var r=RectOf(p); return r.xMin>-7.5f&&r.xMax<7.5f&&r.yMin>-4.0f&&r.yMax<4.0f;}
        public void Clear()=>_placed.Clear();
    }
}
