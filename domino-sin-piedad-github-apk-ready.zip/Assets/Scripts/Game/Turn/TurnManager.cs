using UnityEngine;
namespace SinPiedad.Game.Turn {
    public sealed class TurnManager : MonoBehaviour {
        public int CurrentPlayer {get;private set;}=0; public int Direction {get;private set;}=1;
        public void Next(){CurrentPlayer=(CurrentPlayer+Direction+4)%4;}
        public void Reverse(){Direction*=-1; Next();}
    }
}
