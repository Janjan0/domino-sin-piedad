using UnityEngine;
namespace SinPiedad.Game.Score {
    public sealed class ScoreController : MonoBehaviour {
        public int[] Scores {get;} = new int[4];
        public void Add(int player,int points){if(player>=0&&player<Scores.Length) Scores[player]+=Mathf.Max(0,points);}
    }
}
