using System;
using System.Collections.Generic;
using UnityEngine;
using SinPiedad.UI;

namespace SinPiedad.Game {
    public enum Power { Shield, Bomb, Reverse, Look, Wild, Ghost, Impulse, DoubleAttack }
    public enum Sabotage { Block=1, Bomb=2, Demolition=3 }

    public sealed class PlayerState {
        public string Name; public bool Human; public List<DominoTile> Hand=new();
        public int Powder=1, Fury=0, Score=0; public bool Shielded;
        public PlayerState(string n,bool h){Name=n;Human=h;}
    }

    public sealed class SinPiedadGame : MonoBehaviour {
        public BoardModel Board {get;private set;} = new();
        public List<PlayerState> Players {get;private set;} = new();
        public int CurrentPlayer {get;private set;}=0;
        public int Direction {get;private set;}=1;
        public List<DominoTile> Boneyard {get;private set;}=new();
        public bool DelationOpen {get;private set;}=false;
        public string Status {get;private set;}="Tu turno";
        System.Random rng=new();
        public event Action Changed;
        public void StartMatch(){
            Board.Clear(); Boneyard.Clear();
            Players.Clear(); Players.Add(new PlayerState("Tú",true)); Players.Add(new PlayerState("Ana",false)); Players.Add(new PlayerState("Carlos",false)); Players.Add(new PlayerState("Pedro",false));
            var deck=new DominoDeck(); deck.Shuffle(rng); foreach(var t in deck.Tiles) Boneyard.Add(t); foreach(var p in Players){p.Hand.Clear(); for(int i=0;i<7;i++) p.Hand.Add(Draw()); p.Powder=1;p.Fury=0;p.Score=0;p.Shielded=false;}
            CurrentPlayer=0;Direction=1;Status="Tu turno — juega una ficha";Changed?.Invoke();
        }
        DominoTile Draw(){var t=Boneyard[^1];Boneyard.RemoveAt(Boneyard.Count-1);return t;}
        public bool PlayHuman(int handIndex,bool right,Vector2 desired){
            if(CurrentPlayer!=0 || handIndex<0 || handIndex>=Players[0].Hand.Count) return false;
            var t=Players[0].Hand[handIndex]; if(!Board.TryPlace(t,right,desired,out _)){Status="No encaja ahí";Changed?.Invoke();return false;}
            Players[0].Hand.RemoveAt(handIndex); RewardOnPlay(Players[0],t); AfterPlay(); return true;
        }
        void RewardOnPlay(PlayerState p,DominoTile t){ if(t.IsDouble)p.Fury=Mathf.Min(5,p.Fury+1); if(Board.Chain.Count>1)p.Fury=Mathf.Min(5,p.Fury+1); if(p.Fury>=5)Status="🔥 FURIA ACTIVADA"; }
        void AfterPlay(){ if(Players[0].Hand.Count==0){Players[0].Score+=10;Status="🏆 ¡GANASTE LA MANO!";Changed?.Invoke();return;} AdvanceTurn(); }
        void AdvanceTurn(){CurrentPlayer=(CurrentPlayer+Direction+Players.Count)%Players.Count; Status=$"Turno de {Players[CurrentPlayer].Name}"; Changed?.Invoke(); if(CurrentPlayer!=0) Invoke(nameof(BotTurn),0.55f);}
        void BotTurn(){ if(CurrentPlayer==0)return; var p=Players[CurrentPlayer];
            // occasional sabotage
            if(p.Powder>=2 && rng.NextDouble()<0.13){ p.Powder-=2; OpenDelation(); return; }
            int idx=-1; bool right=true;
            for(int i=0;i<p.Hand.Count;i++){
                var t=p.Hand[i]; if(Board.Empty || t.Matches(Board.LeftValue)){idx=i;right=false;break;} if(t.Matches(Board.RightValue)){idx=i;right=true;break;}
            }
            if(idx>=0){var t=p.Hand[idx]; Board.TryPlace(t,right,Vector2.zero,out _);p.Hand.RemoveAt(idx);RewardOnPlay(p,t); if(p.Hand.Count==0){p.Score+=10;Status=$"🏆 {p.Name} ganó la mano";Changed?.Invoke();return;}}
            else if(Boneyard.Count>0) p.Hand.Add(Draw());
            AdvanceTurn();
        }
        public void UsePower(Power power){
            var p=Players[CurrentPlayer]; int cost=power switch{Power.DoubleAttack=>2,Power.Wild=>1,Power.Ghost=>1,Power.Impulse=>1,Power.Shield=>1,Power.Bomb=>1,Power.Reverse=>1,Power.Look=>1,_=>1};
            if(p.Fury>=5){p.Fury=0;cost=0;} if(p.Powder<cost){Status="No tienes Pólvora suficiente";Changed?.Invoke();return;} p.Powder-=cost;
            switch(power){case Power.Shield:p.Shielded=true;break;case Power.Reverse:Direction*=-1;break;case Power.Impulse:p.Fury=Mathf.Min(5,p.Fury+1);break;case Power.Bomb: if(Boneyard.Count>0){int n=(CurrentPlayer+Direction+Players.Count)%Players.Count;Players[n].Hand.Add(Draw());} OpenDelation();break;case Power.Look:Status="👀 Mirada: revisa la mano rival (MVP visual)";break;}
            Changed?.Invoke();
        }
        public void OpenDelation(){DelationOpen=true;Status="🚨 MESA DE DELACIÓN — 20 segundos";Changed?.Invoke();}
        public void CastVote(int target){ if(!DelationOpen)return; DelationOpen=false; Status=target==1?"🔥 ¡LA MESA DESCUBRIÓ AL CULPABLE!":"💀 ¡EL CULPABLE ESCAPÓ!"; Changed?.Invoke(); AdvanceTurn(); }
        public void NoDelate(){if(!DelationOpen)return;DelationOpen=false;Status="🤐 Nadie delató";Changed?.Invoke();AdvanceTurn();}
    }
}
