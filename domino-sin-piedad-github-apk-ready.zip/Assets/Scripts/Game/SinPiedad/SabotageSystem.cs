using UnityEngine;
namespace SinPiedad.Game.SinPiedad {
    public enum SabotageType { Bloqueo, Bomba, Demolicion }
    public readonly struct SabotageEvent { public readonly int Actor; public readonly SabotageType Type; public SabotageEvent(int actor,SabotageType type){Actor=actor;Type=type;} }
    public sealed class SabotageSystem : MonoBehaviour {
        public event System.Action<SabotageEvent> SabotageTriggered;
        public bool Trigger(int actor,SabotageType type,SinPiedadState state){int cost=type switch{SabotageType.Bloqueo=>1,SabotageType.Bomba=>2,_=>3}; if(!state.SpendPowder(cost))return false; SabotageTriggered?.Invoke(new SabotageEvent(actor,type)); return true;}
    }
}
