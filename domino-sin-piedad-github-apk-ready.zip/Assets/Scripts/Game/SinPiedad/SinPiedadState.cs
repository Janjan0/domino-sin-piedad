using UnityEngine;
namespace SinPiedad.Game.SinPiedad {
    public sealed class SinPiedadState : MonoBehaviour {
        public int Powder {get;private set;}=1; public int Furia {get;private set;}=0;
        public bool FuriaArmed {get;private set;}
        public void AddPowder(int n)=>Powder=Mathf.Clamp(Powder+n,0,5);
        public bool SpendPowder(int n){if(Powder<n)return false;Powder-=n;return true;}
        public void AddFuria(int n){Furia=Mathf.Clamp(Furia+n,0,5);if(Furia>=5)FuriaArmed=true;}
        public bool ConsumeFuria(){if(!FuriaArmed)return false;Furia=0;FuriaArmed=false;return true;}
    }
}
