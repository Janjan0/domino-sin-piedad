using System.Collections.Generic;
using UnityEngine;
namespace SinPiedad.Game.SinPiedad {
    public sealed class DelationSystem : MonoBehaviour {
        readonly Dictionary<int,int> votes=new(); public bool Open{get;private set;}
        public void OpenWindow(){votes.Clear();Open=true;} public bool Vote(int voter,int target){if(!Open||votes.ContainsKey(voter))return false;votes[voter]=target;return true;}
        public Dictionary<int,int> Close(){Open=false;var result=new Dictionary<int,int>();foreach(var v in votes.Values){if(!result.ContainsKey(v))result[v]=0;result[v]++;}return result;}
    }
}
