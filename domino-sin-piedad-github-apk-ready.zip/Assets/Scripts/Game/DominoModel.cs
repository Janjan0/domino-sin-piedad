using System;
using System.Collections.Generic;
using UnityEngine;

namespace SinPiedad.Game {
    [Serializable]
    public struct DominoTile {
        public int A, B;
        public DominoTile(int a, int b) { A=a; B=b; }
        public bool IsDouble => A==B;
        public int Sum => A+B;
        public bool Matches(int n) => A==n || B==n;
        public int Other(int n) => A==n ? B : (B==n ? A : -1);
        public override string ToString() => $"{A}|{B}";
    }

    public sealed class DominoDeck {
        public readonly List<DominoTile> Tiles = new();
        public DominoDeck() { Reset(); }
        public void Reset() { Tiles.Clear(); for(int a=0;a<=6;a++) for(int b=a;b<=6;b++) Tiles.Add(new DominoTile(a,b)); }
        public void Shuffle(System.Random r) { for(int i=Tiles.Count-1;i>0;i--){int j=r.Next(i+1); (Tiles[i],Tiles[j])=(Tiles[j],Tiles[i]);} }
        public DominoTile Draw(){ var t=Tiles[^1]; Tiles.RemoveAt(Tiles.Count-1); return t; }
    }

    public enum BoardDir { Right, Down, Left, Up }
    [Serializable]
    public sealed class PlacedTile {
        public DominoTile Tile;
        public Vector2 Position;
        public BoardDir Dir;
        public bool Reversed;
        public PlacedTile(DominoTile tile, Vector2 pos, BoardDir dir, bool reversed){Tile=tile;Position=pos;Dir=dir;Reversed=reversed;}
    }

    public sealed class BoardModel {
        public readonly List<PlacedTile> Chain = new();
        public int LeftValue=-1, RightValue=-1;
        const float Step=1.18f;
        const float Bound=5.9f;
        public bool Empty => Chain.Count==0;
        public void Clear(){Chain.Clear(); LeftValue=RightValue=-1;}
        public bool CanPlay(DominoTile t)=>Empty || t.Matches(LeftValue) || t.Matches(RightValue);
        public bool TryPlace(DominoTile t, bool right, Vector2 desired, out PlacedTile placed){
            placed=null;
            if(!CanPlay(t)) return false;
            if(Empty){ var p=new PlacedTile(t,Vector2.zero,BoardDir.Right,false); Chain.Add(p); LeftValue=t.A; RightValue=t.B; placed=p; return true; }
            int endpoint = right ? RightValue : LeftValue;
            if(!t.Matches(endpoint)) return false;
            int other=t.Other(endpoint);
            int idx=right ? Chain.Count-1 : 0;
            BoardDir baseDir = right ? Chain[idx].Dir : Opposite(Chain[0].Dir);
            BoardDir chosen=ChooseDir(baseDir, desired, right);
            Vector2 anchor = right ? Chain[idx].Position : Chain[0].Position;
            Vector2 pos = anchor + DirVec(chosen)*Step;
            bool rev = right ? t.A!=endpoint : t.B!=endpoint;
            var candidate=new PlacedTile(t,pos,chosen,rev);
            if(Mathf.Abs(pos.x)>Bound || Mathf.Abs(pos.y)>Bound) return false;
            foreach(var x in Chain) if(Vector2.Distance(x.Position,pos)<0.82f) return false;
            if(right){Chain.Add(candidate);RightValue=other;} else {Chain.Insert(0,candidate);LeftValue=other;}
            placed=candidate; return true;
        }
        BoardDir ChooseDir(BoardDir baseDir, Vector2 desired, bool right){
            Vector2 d=desired;
            if(d.sqrMagnitude<0.01f) return baseDir;
            float ax=Mathf.Abs(d.x), ay=Mathf.Abs(d.y);
            if(ax>ay) return d.x>=0?BoardDir.Right:BoardDir.Left;
            return d.y>=0?BoardDir.Up:BoardDir.Down;
        }
        static BoardDir Opposite(BoardDir d)=>(BoardDir)(((int)d+2)%4);
        public static Vector2 DirVec(BoardDir d)=>d switch{BoardDir.Right=>Vector2.right,BoardDir.Left=>Vector2.left,BoardDir.Up=>Vector2.up,_=>Vector2.down};
    }
}
