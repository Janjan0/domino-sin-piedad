using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SinPiedad.Game;

namespace SinPiedad.UI {
    public sealed class RuntimeUI : MonoBehaviour {
        SinPiedadGame game; Canvas canvas; Text status; Text resources; Transform handRoot; Transform boardRoot; GameObject votePanel;
        readonly List<GameObject> handObjects=new();
        public void Init(SinPiedadGame g){game=g; Build(); game.Changed+=Refresh; Refresh();}
        Font Font=>Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        void Build(){
            canvas=new GameObject("Canvas").AddComponent<Canvas>();canvas.renderMode=RenderMode.ScreenSpaceOverlay;canvas.gameObject.AddComponent<CanvasScaler>().uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;canvas.GetComponent<CanvasScaler>().referenceResolution=new Vector2(1280,720);canvas.gameObject.AddComponent<GraphicRaycaster>();
            var bg=Box("Table",canvas.transform,new Vector2(0,0),new Vector2(0,0),new Vector2(1280,720)); bg.GetComponent<Image>().color=new Color(.055f,.035f,.025f,1);
            var felt=Box("Felt",canvas.transform,new Vector2(0,0),new Vector2(0,0),new Vector2(1120,590)); felt.GetComponent<Image>().color=new Color(.09f,.18f,.13f,1);
            status=Label(canvas.transform,"",28,TextAnchor.MiddleCenter,new Vector2(0,260),new Vector2(850,60)); status.color=Color.white;
            resources=Label(canvas.transform,"",20,TextAnchor.UpperLeft,new Vector2(-560,300),new Vector2(300,80));
            boardRoot=new GameObject("Board").transform; boardRoot.SetParent(canvas.transform,false);
            handRoot=new GameObject("Hand").transform; handRoot.SetParent(canvas.transform,false);
            var powers=new[]{("🛡",Power.Shield),("💣",Power.Bomb),("🔄",Power.Reverse),("👀",Power.Look)}; for(int i=0;i<powers.Length;i++){var b=Button(canvas.transform,powers[i].Item1,20,new Vector2(-360+i*180,-295),new Vector2(150,55));var p=powers[i].Item2;b.onClick.AddListener(()=>game.UsePower(p));}
            var restart=Button(canvas.transform,"Nueva mano",18,new Vector2(500,300),new Vector2(180,50));restart.onClick.AddListener(game.StartMatch);
        }
        GameObject Box(string n,Transform parent,Vector2 anchor,Vector2 pos,Vector2 size){var go=new GameObject(n);go.transform.SetParent(parent,false);var r=go.AddComponent<RectTransform>();r.anchorMin=r.anchorMax=new Vector2(.5f,.5f);r.anchoredPosition=pos;r.sizeDelta=size;go.AddComponent<Image>();return go;}
        Text Label(Transform parent,string txt,int size,TextAnchor align,Vector2 pos,Vector2 sz){var go=new GameObject("Text");go.transform.SetParent(parent,false);var r=go.AddComponent<RectTransform>();r.anchorMin=r.anchorMax=new Vector2(.5f,.5f);r.anchoredPosition=pos;r.sizeDelta=sz;var t=go.AddComponent<Text>();t.font=Font;t.fontSize=size;t.alignment=align;t.text=txt;return t;}
        Button Button(Transform parent,string txt,int size,Vector2 pos,Vector2 sz){var go=Box("Button",parent,Vector2.zero,pos,sz);go.GetComponent<Image>().color=new Color(.55f,.28f,.06f,1);var b=go.AddComponent<Button>();Label(go.transform,txt,size,TextAnchor.MiddleCenter,Vector2.zero,sz);return b;}
        void Refresh(){
            if(status==null)return; status.text=game.Status; var me=game.Players.Count>0?game.Players[0]:null; if(me!=null)resources.text=$"🔥 Pólvora {me.Powder}/5\n⚡ Furia {me.Fury}/5";
            foreach(var o in handObjects)Destroy(o);handObjects.Clear(); if(me==null)return; float start=-(me.Hand.Count-1)*58f;
            for(int i=0;i<me.Hand.Count;i++){int idx=i;var t=me.Hand[i];var b=Button(handRoot,$"{t.A} | {t.B}",24,new Vector2(start+i*116,-220),new Vector2(100,70));b.onClick.AddListener(()=>game.PlayHuman(idx,true,Vector2.right));handObjects.Add(b.gameObject);}
        }
    }
}
