using UnityEngine;
using SinPiedad.Game;
using SinPiedad.UI;

namespace SinPiedad.Core {
    public sealed class GameBootstrap : MonoBehaviour {
        void Awake(){Application.targetFrameRate=60;Screen.orientation=ScreenOrientation.LandscapeLeft;}
        void Start(){var g=gameObject.AddComponent<SinPiedadGame>();var ui=gameObject.AddComponent<RuntimeUI>();ui.Init(g);g.StartMatch();}
    }
}
