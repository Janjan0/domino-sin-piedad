using UnityEngine;
namespace SinPiedad.Input {
    public sealed class DragTouch : MonoBehaviour { public Vector2 Position {get;private set;} public bool Dragging {get;private set;}
        void Update(){if(UnityEngine.Input.touchCount>0){var t=UnityEngine.Input.GetTouch(0);Position=t.position;Dragging=t.phase!=TouchPhase.Ended&&t.phase!=TouchPhase.Canceled;}}
    }
}
