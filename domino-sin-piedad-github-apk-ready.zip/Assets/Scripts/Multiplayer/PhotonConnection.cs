using UnityEngine;
namespace SinPiedad.Multiplayer {
    // Adapter seam: the recovered APK uses Photon PUN/Realtime. The reconstruction keeps this isolated so a licensed Photon package can be plugged in later.
    public sealed class PhotonConnection : MonoBehaviour { public bool Connected {get;private set;} public void Connect(){Connected=true;} public void Disconnect(){Connected=false;} }
}
