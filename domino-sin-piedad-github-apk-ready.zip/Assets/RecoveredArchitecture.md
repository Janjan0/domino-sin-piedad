# Recovered architecture map

Source APK: Domino Republic 17.3.1877.

Recovered names mapped into the reconstruction:
- Game/Domino: DominoValidation, DominoDeck, DominoValue, DominoesProperties, AutoPlaceDomino, Move, ReturnToStart.
- Game/Table: Table, DominoesOnTable, PlaysMove, PlacementManager, TableColliderController.
- Game/Turn: TurnManager.
- Game/Score: ScoreController, LockedGame, EndRoundManager, WinController, WinScore.
- Game/Bot: Bot, BotInfo.
- Input: DragTouch, TouchManager, PressDetector, TapsEvents, InputHelper.
- Multiplayer: PhotonConnection, RoomManager, RoomController, MatchManager, PublicRoom, RandomRoom, PrivateRoom.

This project implements the functional seams and a collision-safe chain model from scratch. It does not embed proprietary extracted assets.
