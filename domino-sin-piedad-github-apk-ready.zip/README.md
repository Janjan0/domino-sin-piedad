# Dominó: Sin Piedad

Proyecto Unity 6000.3.0f1 reconstruido para Android.

Incluye núcleo de dominó doble-6, IA básica, cadena, turnos, Pólvora/Furia, poderes, sabotaje, delación y HUD runtime.

## Compilación desde Android

El proyecto incluye `.github/workflows/build-apk.yml` para generar `SinPiedad.apk` en GitHub Actions usando GameCI.

Consulta `README-ANDROID.md` para el procedimiento.
