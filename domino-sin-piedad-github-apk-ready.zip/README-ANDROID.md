# Dominó: Sin Piedad — APK desde Android

Este repositorio está preparado para compilar el proyecto Unity en la nube usando GitHub Actions + GameCI.

## Qué necesitas

- Un teléfono Android.
- Una cuenta de GitHub.
- Una cuenta de Unity.
- Una licencia Unity válida para el build de CI. GameCI requiere una licencia/activación de Unity para compilar el proyecto.

## Flujo

1. Sube este proyecto a un repositorio GitHub.
2. En GitHub abre **Settings → Secrets and variables → Actions**.
3. Crea el secret `UNITY_LICENSE` con el contenido de tu licencia de Unity.
4. Abre **Actions → Build Dominó Sin Piedad APK → Run workflow**.
5. Cuando termine, abre la ejecución y descarga el artifact **Domino-Sin-Piedad-APK**.
6. Dentro encontrarás `SinPiedad.apk`.

El workflow usa Unity 6000.3.0f1, Android y `androidPackage`, por lo que la salida es un APK y no un AAB.

## Importante

El proyecto crea la escena y configura Android automáticamente mediante `BuildAndSetup.Build`, por lo que no necesitas abrir Unity para preparar la escena antes de ejecutar el workflow.
